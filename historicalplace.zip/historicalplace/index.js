let models = 
[
    {
        name:"Delhi",
        picture:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSiLY1PdnwimaYp_5tdoGgG_g02vfnt_SEPBQ&s",
        rating:5
    },

    {
        name:"karnataka",
        picture:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwa8qZGBzfQNQk-sx6VUVR_Gwnd4ZYgEWIFw&s",
        rating:5
    },

    {
        name:"shtershok",
        picture:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqTZ4FmiIPoe_zVxfXgv_CXc6b3T0OaRZjQg&s",
        rating:5
    },

    {
        name:"Times of india",
        picture:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlVsncSpbvOwQYbTU3fEnzQNXmbeIzRvjY3g&s",
        rating:5
    },

    {
        name:"globalcastway",
         picture:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTcX_qhT3xqlr-S68WQDh4PyPcj5o9c6pjHzQ&s",
        rating:5    
    },
];



function searchModel()
{

  let modelName =  document.getElementById("search").value;
   if(modelName!=="")
   {
    let store = models.filter(function(model)
    {
        return model.name.includes(modelName)
    })
    displayModel(store);
   }
}

function displayModel(doc)
{
    document.getElementById("model").innerHTML=""
    let htmlcode = ``;
    for(i=0;i<doc.length;i++)
    {
        htmlcode=htmlcode+
        ` <div class="model">
        <img class="model-store" src="${doc[i]. picture}" alt="">
    </div>`
    }
  document.getElementById("model").innerHTML=htmlcode;
}
displayModel(models);